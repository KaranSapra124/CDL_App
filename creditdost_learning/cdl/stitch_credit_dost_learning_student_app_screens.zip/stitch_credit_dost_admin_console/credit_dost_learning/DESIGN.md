---
name: Credit Dost Learning
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#684000'
  on-tertiary: '#ffffff'
  tertiary-container: '#885500'
  on-tertiary-container: '#ffd4a4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  caption:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 3rem
---

## Brand & Style

This design system delivers an executive-tier, high-density enterprise administration environment for modern educational operations and fintech-aligned credit learning architectures. Combining the surgical precision of modern developer tools with the balanced ergonomics of world-class financial interfaces, the visual tone establishes immediate technical authority, operational clarity, and institutional trust.

The interface prioritizes content clarity over decorative ornamentation. Every interactive surface, container boundary, and typographic node serves unambiguous information hierarchy. Data density is achieved through rigorous spatial math rather than visual crowding, ensuring operators can scan telemetry, student cohorts, billing streams, and curriculum pipelines without cognitive fatigue. Micro-interactions are immediate and mechanical, reinforcing a sense of low-latency enterprise efficiency.

## Colors

The system uses an engineered cool-slate light spectrum paired with an electric indigo core and explicit semantic accents.

- **Background & Canvas:** Canvas layers transition from crisp pure white (`#FFFFFF`) on interactive cards to cool slate washes (`#F8FAFC`, `#F1F5F9`) on secondary underlays, app canvas boundaries, and structural troughs.
- **Text & Typography Hierarchy:** Deep charcoal slate (`#0F172A`) commands high-contrast primary content; muted slate (`#334155`) anchors descriptive copy and secondary headers; cool slate (`#64748B`) drives metadata, timestamps, and contextual hints; pale slate (`#94A3B8`) is reserved for disabled cues and inline divider icons.
- **Primary Brand Accents:** Pure indigo (`#4F46E5`) drives all focused interactions, primary actions, and selected state outlines. Hover interactions transition to deep indigo (`#4338CA`), while contextual highlights sit on soft indigo wash surfaces (`#EEF2FF`).
- **Semantic Accents:** 
  - Emerald (`#10B981`) denotes active cohorts, successful verification states, and revenue accruals.
  - Amber (`#F59E0B`) signifies pending evaluations, batch queueing, and incomplete profiles.
  - Ruby (`#EF4444`) handles credit underwriting rejections, billing failures, and operational warnings.
- **Structural Delimiters:** Hairline borders rely on precise cool grays (`#E2E8F0` for structural containers, `#CBD5E1` for hover states and divider rules).

## Typography

Typography balances tabular numerical density with crisp structural legibility across administrative payloads. Built entirely on an uncompromised implementation of `Inter`, letterforms benefit from optical tracking adjustments calibrated for low-glare dashboard environments.

- **Tabular Numerics:** All currency (`₹ / INR`), telemetry meters, student identification strings, and operational timestamps must use `font-feature-settings: "tnum" 1` to guarantee vertical column alignment across dense tables and data cards.
- **Section Micro-Labels:** Elements categorized under `label-sm` and `caption` (such as metric trends, breadcrumbs, and structural category headers) enforce uppercase casing with calibrated positive tracking (`0.04em` to `0.06em`) to preserve legibility at micro scales without demanding unnecessary vertical canvas budget.
- **Editorial Balance:** Headlines maintain deliberate negative tracking (`-0.01em` to `-0.02em`) to produce cohesive, polished headings reminiscent of top-tier software consoles.

## Layout & Spacing

The layout is built on a responsive 12-column fluid grid system pinned to explicit side navigation and top utility anchors. Spacing adheres to a strict 4px base increment rhythm designed to support information-dense administrative workspaces.

- **Shell Architecture:** 
  - **Sidebar:** Width is fixed at 264px when expanded, collapsing down to an icon-only dock of 68px at the user's command or on medium-tier screens.
  - **Header Utility:** Pinned to a fixed 56px height, hosting global breadcrumbs, the Command+K palette trigger, system health signals, and administrative profiles.
  - **Main Work Area:** Occupies the remaining viewport width, scaling dynamically between fluid table configurations and restrained max-width constraints (max 1600px) on wide viewports to prevent line-length drift in detailed editorial editors.
- **Adaptive Breakpoints:**
  - **Mobile (< 768px):** Navigation drawer tucks away behind an off-canvas overlay. Canvas margins drop to `margin: 1rem`, gutters compress to `gutter: 1rem`, and complex multi-column grids collapse into vertical linear cards.
  - **Tablet (768px - 1024px):** Sidebar persists in compact 68px icon-only form. Content layout scales across 8-column formats with `margin-md: 1.5rem`.
  - **Desktop (> 1024px):** Unrestricted 12-column dynamic framework with persistent navigation, structured data grids, split-screen inspectors, and nested contextual panels using `gutter-lg: 1.5rem`.

## Elevation & Depth

Visual hierarchy is communicated through structural layering and razor-thin borders rather than diffuse, floating drop shadows. The design system rejects heavy blurs in favor of crisp boundaries and physical containment.

- **Baseline Containment:** Standard cards, table rows, and secondary layout panes occupy the z-0 canvas layer, separated solely by 1px solid hairline borders (`#E2E8F0`). Surfaces sit directly on pure `#FFFFFF` over `#F8FAFC`.
- **Micro-Elevation (Level 1):** Interactive cards, hover states, and segmented controls employ a compound ambient outline: `0 1px 2px 0 rgba(15, 23, 42, 0.05)`, reinforced by an internal inset border `inset 0 0 0 1px rgba(226, 232, 240, 0.8)`.
- **Floating Overlays (Level 2):** Context menus, popover tooltips, and floating filter docks float directly over active content using a controlled shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)` enclosed by a crisp `#CBD5E1` boundary.
- **Global Modals & Command Palettes (Level 3):** Modal dialogues and the central `Command + K` omnibar use high-impact depth: `0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.04)` over a semi-transparent tinted backdrop scrim (`rgba(15, 23, 42, 0.4)` with an optical `backdrop-blur(4px)`).

## Shapes

The geometry balances modern precision with subtle ergonomic curvature. Base structural elements use 8px (`0.5rem`) corner radiuses, balancing compact density with clean visual breaks.

- **Micro Components (Chips, Badges, Pills, Buttons):** Standard interactive elements leverage an 8px radius (`0.5rem`). Status indicators and metadata tags take an optional full-pill (`9999px`) configuration to contrast distinctly against rectangular data containers.
- **Standard Containers (Cards, Sheet Panels, Modals):** Medium surface items transition to a 12px radius (`rounded-lg` / `0.75rem`) to create smooth structural nesting when framing internal elements.
- **Nested Containment Formula:** Child elements within rounded cards must maintain an optical inner radius calculated as `R_outer - Padding` to preserve geometric harmony and avoid awkward border-radius pinching.

## Components

### Buttons
- **Primary:** Background `#4F46E5`, foreground `#FFFFFF`, font weight 500, height 36px (compact) or 40px (default), corner radius 8px. Hover state deepens to `#4338CA`. Active state translates down 0.5px. Focused states produce a dual-ring: 2px white gap followed by a 2px `#4F46E5` outline.
- **Secondary / Outline:** Background `#FFFFFF`, border 1px solid `#E2E8F0`, foreground `#0F172A`. Hover: background `#F8FAFC`, border color `#CBD5E1`.
- **Ghost:** Background transparent, foreground `#334155`. Hover: background `#F1F5F9`, foreground `#0F172A`.
- **Destructive:** Background `#EF4444`, foreground `#FFFFFF`. Hover: `#DC2626`.

### Inputs & Global Search
- **Text Inputs:** Height 36px, background `#FFFFFF`, border 1px solid `#CBD5E1`, internal padding 8px 12px, font size 14px (`body-md`), text `#0F172A`, placeholder `#94A3B8`. Active focus immediately swaps border to `#4F46E5` paired with a 1px solid box-shadow ring in `rgba(79, 70, 229, 0.2)`.
- **Command + K Palette:** Centered dialog width 640px, elevated Level 3, featuring an icon-prefixed search input with immediate keyboard navigation pills (e.g., `ESC`, `↵`, `↑↓`) rendered as tactile mini-capsules with subtle bottom-border bevels.

### Chips & Semantic Badges
- **Structure:** Micro height of 22px, padding 2px 8px, font size 11px (`label-sm`), uppercase tracking, radius 9999px (full pill).
- **Success:** Background `#ECFDF5`, text `#065F46`, border 1px solid `#A7F3D0`. Includes a 6px solid emerald dot.
- **Warning / Pending:** Background `#FFFBEB`, text `#92400E`, border 1px solid `#FDE68A`. Includes a 6px solid amber dot.
- **Critical / Failed:** Background `#FEF2F2`, text `#991B1B`, border 1px solid `#FECACA`. Includes a 6px solid ruby dot.
- **Neutral / Draft:** Background `#F1F5F9`, text `#475569`, border 1px solid `#E2E8F0`.

### Data Tables & Lists
- **Header:** Height 38px, background `#F8FAFC`, border-bottom 1px solid `#E2E8F0`, typography `label-sm` with text `#64748B`.
- **Rows:** Height 48px standard, background `#FFFFFF`, border-bottom 1px solid `#F1F5F9`. Hover creates an immediate background shift to `#F8FAFC`.
- **Cells:** Vertical alignment center, typography `body-md` for primary identifiers and `body-sm` (tabular numerals) for currency/data metrics.

### Checkboxes & Radio Controls
- **Checkboxes:** Size 16px by 16px, corner radius 4px, border 1.5px solid `#CBD5E1`, background `#FFFFFF`. Selected state transitions background to `#4F46E5`, border to `#4F46E5`, rendering an optically centered white check icon.
- **Radio Buttons:** Size 16px by 16px, fully circular, border 1.5px solid `#CBD5E1`. Selected state renders an inner 6px solid `#4F46E5` core centered on a crisp white surface.

### Navigation Shell & Breadcrumbs
- **Sidebar Groups:** Category headers display in `label-sm` uppercase `#94A3B8` with 8px horizontal padding. Navigation items use 36px height, corner radius 8px, icon prefix (20px), and flexible pill badges. Active state uses `#EEF2FF` background, `#4F46E5` foreground, and a 500 font weight.
- **Top Navigation Bar:** Sticky top position, background `#FFFFFF` with 80% opacity and `backdrop-filter: blur(8px)`. Hairline border-bottom `#E2E8F0`. Integrates horizontal breadcrumb items split by clean `/` icons in `#CBD5E1`.